Thank you for downloading this free icon set from BrianYerkes.com !

These icons are licensed under the Creative Commons license and can be 
used for personal and/or commercial purposes. No attribution is needed by those using them, 
but a link in your blogroll or on your site is very much appreciated!

http://creativecommons.org/licenses/by/3.0/us/